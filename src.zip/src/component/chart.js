import React from "react";
import '../css/book_detail.css'
import '../css/chart.css'
function formatPrice(price){
    if(typeof price !=="number"){
        price = Number("aaa") || 0
    }
    return "¥"+ price.toFixed(2)
}

class Movie extends React.Component{
    constructor(){
        super()
        this.state={
            books:[
                {id:1,name:"《算法导论》", category:'编程',price:25,numbers:1},
                {id:2,name:"《编程艺术》", category:'编程',price:45,numbers:1},
                {id:3,name:"《代码大全》", category:'编程',price:15,numbers:1},
                {id:4,name:"《天演论二》", category:'自然科学',price:115,numbers:1},
            ],
        }
    }

    renderBooks(){
        return(
            <div>
                <table id= "shopping_cart_info">
                    <thead>
                    <tr>
                        <th width="100px" >序号</th>
                        <th >书籍名称</th>
                        <th width="400px" height="42px">分类</th>
                        <th width="400px" height="42px">价格</th>
                        <th width="400px" height="42px">购买数量</th>
                        <th width="400px" height="42px">操作</th>

                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.books.map((item,index)=>{
                            return (
                                <tr>
                                    <td>{index+1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.category}</td>
                                    <td>{formatPrice(item.price)}</td>
                                    <td>
                                        <button onClick={()=>this.changeBookCount(index,-1)}
                                                disabled={item.numbers ==1}>-</button>
                                        <span>{item.numbers}</span>
                                        <button onClick={()=>this.changeBookCount(index,1)}>+</button>
                                    </td>
                                    <td><button onClick={()=>this.removeItem(index)}>移除</button></td>
                                </tr>)
                        })
                    }
                    </tbody>
                </table>
                <div className="continueorsubmit fr">
                    <button type="button" className="continue">继续购物</button>
                    <button type="submit" className="submit">提交订单</button>
                </div>
                <p>总价格:{this.getTotalprice()}</p>
            </div>)
    }

    renderNone(){
        return <h2>购物车为空</h2>
    }
    render() {
        const {books} = this.state
        return books.length ==0?this.renderNone():this.renderBooks()
    }
    changeBookCount(index,count){
        const newBooks =[...this.state.books]
        newBooks[index].numbers +=count
        this.setState({
            books:newBooks
        })
    }
    removeItem(index){
        this.setState({
            books:this.state.books.filter((item,indey)=>index !=indey)
        })
    }

    getTotalprice(){
        let totalPrice = this.state.books.reduce((pre,item)=>{
            return pre+item.price * item.numbers
        },0)
        return formatPrice(totalPrice)
    }
}
export default Movie;


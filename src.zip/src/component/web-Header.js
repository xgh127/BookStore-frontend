import React from "react";
import '../css/basicBackground.css'
import HeaderLogo from '../picture/web_hospital.png'
function Head_img(){
 return(
     <img className="title"
          src={HeaderLogo}
          alt="HeaderLogo"/>
 ) ;
}

 class WebHeader extends React.Component{

render() {
 return(
     <div className="title-box">
      <Head_img/>
      <h1>待添加属性</h1>
     </div>
 )
}

 }



 export default WebHeader;
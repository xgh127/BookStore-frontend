import React from 'react'
import { Menu,Layout} from 'antd'
import { Icon } from '@ant-design/compatible'
import '../css/Css_of_SideBar.css'
import {history} from "../utils/history";

// const { SubMenu } = Menu;
const { Sider } = Layout;

class WebSideBar extends React.Component {


    //这里设计页面跳转逻辑
    bookOnClick = () => {
        history.push("/");
    };

    render() {
        return (

                < div className="NewSideBar">
                    <Sider>
                        <Menu defaultSelectedKeys={['1']} mode="inline">
                            <Menu.Item key="1" onClick={this.bookOnClick}>
                                <a className="block1">
                               <Icon type="info-circle-o" style={{ fontSize: '24px'}}/>
                                <span style={{ fontSize: '24px'}}> 医生信息查询</span>
                                </a>
                            </Menu.Item>
                            <Menu.Item key="2">
                                <a className="block2">
                                    <Icon type="user" style={{ fontSize: '24px'}} />
                                    <span style={{ fontSize: '24px'}}> 登录/注册</span>
                                </a>
                            </Menu.Item>
                            <Menu.Item key="3">
                                <a className="block3">
                                <Icon type="solution"  style={{ fontSize: '24px'}}/>
                                <span style={{ fontSize: '24px'}}> 网上挂号</span>
                                </a>
                            </Menu.Item>
                            <Menu.Item key="4">
                                <a className="block4">
                                <Icon type="info-circle" style={{ fontSize: '24px'}}/>
                                <span style={{ fontSize: '24px'}}> 挂号查询</span>
                                </a>
                            </Menu.Item>
                        </Menu>
                    </Sider>
                </div>


        );
    }

}
export default WebSideBar;
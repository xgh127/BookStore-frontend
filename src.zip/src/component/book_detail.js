import React from "react";
import '../css/book_detail.css'
class Book_detail extends React.Component{

    constructor(props) {
        super(props);
    }
    render(){
        const product = this.props.product;
        return(
            <div className="books-box">
                <div className="ghxz-02">
                    <article>
                        <img src={product.url}
                             alt={product.name}/>
                        <ul>
                            <li>书名：{product.name}</li>
                            <li>分类：{product.category}</li>
                            <li>作者：{product.author}</li>
                            <li>定价：{product.price}</li>
                            <li>简介：{product.description}</li>
                        </ul>
                    </article>
                    <button >加入购物车</button>
                    <button id="btn" >购买</button>
                </div>
            </div>
        )
    }
}
export default Book_detail;
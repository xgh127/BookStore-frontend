import React from "react";
class WebHome extends React.component(){
    render() {
        return (
            <div>我是Home</div>
        )
    }
}
export default WebHome;
import React from "react";
import '../css/basicBackground.css'

function SubContainer(props) {
    return null;
}

SubContainer.propTypes = {};

class BookDetail extends React.Component{

    constructor(props) {
        super(props);
    }
    render() {
        return (

            <div className="min-box">
                {/*<Route path="/" component={SideBar}/>*/}
                {this.props.SideBar}
                {this.props.Sub}
            </div>

        )
    }
}
export default BookDetail;
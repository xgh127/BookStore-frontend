import React from "react";
class WebTopic extends React.component(){
    render() {
        return (
            <div>我是Topic</div>
        )
    }
}
export default WebTopic;
import React from "react";
class WebAbout extends React.component(){
    render() {
        return (
            <div>我是about page</div>
        )
    }
}
export default WebAbout;
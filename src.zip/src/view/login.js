import React from "react";
import '../css/logincss.css'
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
class Login extends React.Component{
    constructor(props) {
        super(props);
    }
    render()
    {
        return (
            // <div>
            //     {/*<h1><Link to="/first">登录</Link></h1>*/}
            //     <h1>好麻烦</h1>
            // </div>
            <div className="login-Box">
                <img id="user-icon" src="../picture/login_head.jpeg" alt="头像jpg"/>
                    <h3>登录</h3>
                    <form action="">
                        <p>姓名</p>
                        <input type="text" id="name" placeholder="请输入姓名"/>
                            <p>密码</p>
                            <input type="password" id="password" placeholder="请输入密码"/>
                        <h4 align="center"><Link to="/home">登录</Link></h4>
                            <a href="#">忘记密码</a>
                    </form>
            </div>
        )
    }
}
export default Login;
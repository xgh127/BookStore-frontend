const apiURL = "http://localhost:8080";
const frontURL="http://localhost:3000";
const gatewayURL = "http://localhost:8000";
export {apiURL,frontURL,gatewayURL};
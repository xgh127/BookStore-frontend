import './App.css';
import './css/basicBackground.css'
import './component/Table/BookTable';
import './component/BookDetail/BookDetail';
import React from "react";
import ReactDOM from 'react-dom';
import './css/chart.css';
import {BrowserRouter as Router,Route} from 'react-router-dom'
import './css/chart.css'
import {HomeView} from "./view/HomeView";
import {LoginView} from "./view/LoginView";
import {BookDetailView} from "./view/bookDetailView"
import {ChartView} from "./view/ChartView";
import {PersonCenterView} from "./view/PersonCeter";
import {OrderView} from "./view/OrderView";
import {RegisterView} from "./view/RegisterView";
import {history} from "./utils/history";
import {MakeOrderSuccessView} from "./view/Result/MakeOrderSuccess";
import {UserMangePage, UserMangeView} from "./view/Admin/UserMangeView";
import {OrderMangePage, OrderMangeView} from "./view/Admin/OrderManageView";
import {BookMangePage, BookMangeView} from "./view/Admin/BookManageView";
import {AdminPersonCenterView, AdminPersonCeterView, theAdminPersonCenter} from "./view/Admin/AdminPersonCenter";
import {AdminDetail, DisplayBookDetailView} from "./view/Admin/AdminCheckBookDetail";
import {EditBookPage, EditBookView} from "./view/Admin/EditBookView";
import {EditBookSuccessView} from "./view/Result/editBookSuccess";
import {ErrorPageView} from "./view/Result/ErrorPage";
import {PublishBookSuccessView} from "./view/Result/PublishBookSuccess";
import {RegisterSuccessView} from "./view/Result/RegisterSuccess";
import {LogoutSuccessView} from "./view/Result/LogoutSuccess";
import {GlobalSearchResultView, theSearchResult} from "./view/SearchResult/GlobalSearchResultView";
import {MircoServiceView, ServiceView} from "./view/mircoServiceView";
import {AuthorSearchView, theAuthorSearchResult} from "./view/SearchResult/AuthorSearchView";
import {StatisticView} from "./view/Admin/Statistic/StatisticView";

/*直接import的登录页面*/
function AllOfPage(){
    return(
        <Router history={history}>
        <div>
                <Route exact path="/" component={LoginView}/>
                <Route exact path="/register" component={RegisterView}/>
                <Route exact path="/first" component={HomeView}/>
                <Route exact path='/detail' component={BookDetailView}/>
                <Route exact path="/chart" component={ChartView}/>
                <Route exact path="/MakeOrderSuccessView" component={MakeOrderSuccessView}/>
                <Route exact path="/order" component={OrderView}/>
                <Route exact path="/personCenter" component={PersonCenterView}/>
                <Route exact path="/registerSuccess" component={RegisterSuccessView}/>
                <Route exact path="/logoutSuccess" component={LogoutSuccessView}/>
                <Route exact path="/searchResult" component={GlobalSearchResultView}/>
                <Route exact path="/mircoService" component={MircoServiceView}/>
                <Route exact path="/AuthorSearchResult" component={AuthorSearchView}/>
                {/*管理员页面*/}
                <Route exact path = "/UserMange" component={UserMangeView}/>
                <Route exact path = "/Statistic" component={StatisticView}/>
                <Route exact path = "/OrderMange" component={OrderMangeView}/>
                <Route exact path = "/BookMange" component={BookMangeView}/>
                <Route exact path = "/AdminBookDetail" component={DisplayBookDetailView}/>
                <Route exact path = "/AdminPersonalCenter" component={AdminPersonCenterView}/>
                <Route exact path = "/AdminEditBook" component={EditBookView}/>
                <Route exact path = "/Admin/editBookSuccess" component={EditBookSuccessView}/>
                <Route exact path = "/Admin/PublishBookSuccess" component={PublishBookSuccessView}/>
                <Route exact path = "/Error" component={ErrorPageView}/>
        </div>
        </Router>
    )
}
function App() {
  return (
<AllOfPage/>

  )
}
ReactDOM.render(<App/>,document.getElementById("root"));
export default App;

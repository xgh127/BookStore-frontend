import React from "react";
import RegisterForm from "../component/Table/RegisterForm";
import HeaderBar from "../component/Decoration/HeaderBar";
import Container from "../component/Container/Container";
import SubContainer from "../component/Container/subContainer";


class RegisterView extends React.Component{
    render() {
        return(
          <div className="min-box">

                <HeaderBar Head={"注册"}/>
              <div className="register-box">
                <RegisterForm/>
          </div>
          </div>

        )

    }
}
export {RegisterView};
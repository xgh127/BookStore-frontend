import React from "react";
import '../../../css/basicBackground.css'
import AdminSideBar from "../../../component/Decoration/AdminSideBar";
import SubContainer from "../../../component/Container/subContainer";
import HeaderBar from "../../../component/Decoration/HeaderBar";

class StatisticView extends React.Component{

    render() {
        return(
            <div className="min-box">
                <HeaderBar Head={"数据统计"}/>
                <AdminSideBar/>
                <SubContainer elem = {

                    <div >
                        <p>数据统计处</p>

                    </div>
                }>

                </SubContainer>

            </div>
        )
    }
}

export {StatisticView};
import React from "react";
import {getuserConsumeData} from "../../../Service/StatisticService";

class UserConsumption extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userData: [],
            searchText: {},
            searchedColumn: "",
            searchTime: [],
            chartData: [],
        }
        getuserConsumeData({},(data)=> {
            this.setState({
                userData:data.concat([])
            });
        });
    }
    render() {
        return (
            <div>

            </div>
        )
    }
}
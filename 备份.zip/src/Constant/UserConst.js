export const UserConst ={
    USERID:"id",
    USERNAME:"username",
    IDENTITY:"identity",
    NICKNAME:"nickname",
    MAIL:"mail",
    TEL:"tel",
    DESCRIPTION:"description",
}
import {getRequest} from "../utils/ajax";
import {apiURL} from "../config/BaseConfig";

export const getuserConsumeData = (data,callback) => {
    let url = apiURL + "/statistic/userConsume";
    getRequest(url,data,callback);
}
const apiURL = "http://localhost:8080";
const frontURL="http://localhost:3000";
export {apiURL,frontURL};
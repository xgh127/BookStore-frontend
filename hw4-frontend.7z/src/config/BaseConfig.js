const apiURL = "https://localhost:8443";
const frontURL="http://localhost:3000";
export {apiURL,frontURL};